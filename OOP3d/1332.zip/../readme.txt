the cbp file is in .bulid dirctory 
